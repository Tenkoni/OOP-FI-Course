#include <iostream>

class BankAccount
{
public:

    BankAccount ();
    BankAccount (double fundsi, double interesti);
    double getFunds();
    double getInterest();
    void setInterest(double interes);
    void setFunds(double money);
    bool Withdraw(double money);
    void Deposit (double money);
    void Imprimir ();
    void AddInterest ();
    double GetPenalizacion();

private:

    static constexpr double PENAL = 10.0;
    double funds;
    double interest;

};

BankAccount::BankAccount() : funds (0.0), interest (0.0)
{

}

BankAccount::BankAccount (double fundsi, double interesti) : funds (fundsi), interest (interesti)
{
  setFunds(fundsi);
  setInterest(interesti);
}

double BankAccount::getFunds()
{
    return this->funds;
}

void BankAccount::setFunds(double money)
{
    this->funds = money;
}

double BankAccount::getInterest()
{
    return this->interest;
}

void BankAccount::Deposit (double money)
{
    this->funds += money;
}

bool BankAccount::Withdraw (double money)
{
    if (getFunds() < money)
    {
      Deposit(-PENAL);
      return false;
    }
    else
    {
      money *= -1;
      Deposit(money);
    }
    return true;
}



void BankAccount::Imprimir ()
{
    std::cout<<"Fondos totales: "<< getFunds() << "\n" <<"Interes Actual (Mensual): "<< getInterest() * 100 << "%" <<std::endl;
}

void BankAccount::AddInterest()
{
    setFunds( getFunds() + (this->interest * getFunds()));
}

void BankAccount::setInterest(double interes)
{
  interes = interes / 100;
  if (0<=interes and interes <= 0.1){
    interes /= 12;
    this->interest = interes;
  }
  else{
    std::cout<<"Estableciendo interés a un valor seguro (5%)"<<std::endl;
    this->interest = .05/12;
  }
}


double BankAccount::GetPenalizacion ()
{
  return PENAL;
}

int main ()
{
    BankAccount cuentita {20000.0, 8.5};
    cuentita.Imprimir ();
    double nsaldo;
    std::cout << "Ingrese la cantidad a depositar: $";
    std::cin >> nsaldo;
    cuentita.Deposit (nsaldo);
    std::cout << "Ingrese la cantidad a retirar: $";
    std::cin >> nsaldo;
    if (cuentita.Withdraw(nsaldo))
      std::cout << "Cantidad retirada exitosamente." << std::endl;
    else
      std::cout << "Fondos insuficientes, añadiendo penalización de: $"<< cuentita.GetPenalizacion() << std::endl;
    std::cout << "Su saldo actual es de: $" << cuentita.getFunds() <<std::endl;

    cuentita.AddInterest();
    cuentita.Imprimir();


}
